<?php
/**
 * Created by PhpStorm.
 * User: devon
 * Date: 2016-04-20
 * Time: 9:42 AM
 */
$page_title = 'Home | The Fish Taco Finder';
require('header.php');
?>

    <div class="jumbotron">
        <h1>Welcome to the Fish Taco Finder!</h1>
    </div>

<?php require('footer.php'); ?>