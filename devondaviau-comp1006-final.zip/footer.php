</main>

<footer class="alert alert-info">
    <div class="col-sm-10">
        &copy; 2016 | COMP1006 Intro to Web Programming Final Exam | Devon Daviau
    </div>
    <div class="fb-like" data-href="http://gc100022849.computerstudi.es/comp1006/final/default.php" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
</footer>

<!-- js section -->

<script src="Scripts/lib/jquery-2.2.0.min.js"></script>

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</body>
</html>