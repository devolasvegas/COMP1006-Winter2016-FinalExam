<?php
/**
 * Created by PhpStorm.
 * User: devon
 * Date: 2016-03-09
 * Time: 10:44 AM
 */


    $conn = new PDO('mysql:host=sql.computerstudi.es;dbname=gc100022849', 'gc100022849', '9syKsQCu');


?>